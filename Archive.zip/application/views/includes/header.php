<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>User Website</title>
  <link rel="stylesheet" href="<? echo base_url('assets/css/') ?>styles.css" />
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css" integrity="sha384-xOolHFLEh07PJGoPkLv1IbcEPTNtaed2xpHsD9ESMhqIYd0nLMwNLD69Npy4HI+N" crossorigin="anonymous">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>

  
  
<link href="https://cdn.datatables.net/1.13.6/css/jquery.dataTables.min.css" rel="stylesheet">
</head>

<body>
<header>
  <h1>History of Black People</h1>
  <span style="position: absolute; top: 70px; right: 10px; color: #fff;"><? echo $this->session->userdata('user_name') ?></span>
</header>

<div class="container1" style="display: flex;">
  <nav>
    <ul>
      <li><a href="<? echo base_url('home/dashboard') ?>">Home</a></li>
      <li><a href="#about">About</a></li>
      <li><a href="#contact">Contact</a></li>
    
      <?php if ($this->session->userdata('role') == "employee" || $this->session->userdata('role') == "admin") { ?>
        <li class="dropdown"><a href="<? echo base_url('dashboard/pdfs') ?>">Query Database</a></li>
      <? } ?>
      
      <?php if ($this->session->userdata('role') == "admin") { ?>
        <li><a href="<? echo base_url()."users/view" ?>">Users</a></li>
      <? } ?>
      <?php if ($this->session->userdata('user_id')) { ?>
        <li><a href="<? echo base_url()."home/logout" ?>">Logout</a></li>
      <? } ?>  
    </ul>
  </nav>
